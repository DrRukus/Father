//
//  ViewController.swift
//  Filterer
//
//  Created by Daniel Schmidt on 12/5/15.
//  Copyright © 2015 Rukus. All rights reserved.
//

import UIKit

class ViewController: UIViewController , UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    var filteredImage: UIImage?
    let inputImage = UIImage(named: "anime_girl")!
    var image: UIImage?
    var sValue: Int? = 1
    var thresholdValue: UInt8? = 127
    var scalerValue: Double? = 1
    var sigma: Int? = 1
    var blueValue: Double? = 1

    @IBOutlet var imageView: UIImageView!
    @IBOutlet var secondaryMenu: UIView!
    @IBOutlet var bottomMenu: UIView!
    @IBOutlet var filterButton: UIButton!
    @IBOutlet var binaryFilter: UIButton!
    @IBOutlet var brightFilter: UIButton!
    @IBOutlet var gaussFilter: UIButton!
    @IBOutlet var compareButton: UIButton!
    @IBOutlet var blueFilter: UIButton!
    @IBOutlet var editMenu: UIView!
    @IBOutlet var editParameters: UISlider!
    @IBOutlet var editButton: UIButton!
    @IBOutlet var EditFilters: UIView!
    
    @IBAction func onEdit(sender: UIButton) {
        if (sender.selected) {
            hideEditMenu()
            sender.selected = false
        } else {
            showEditMenu()
            sender.selected = true
        }
    }
    
    func showEditMenu() {
        view.addSubview(editMenu)
        
        view.layoutIfNeeded()
        
        self.editMenu.alpha = 0
        UIView.animateWithDuration(0.4) {
            self.editMenu.alpha = 1.0
        }
    }
    
    func hideEditMenu() {
        UIView.animateWithDuration(0.4, animations: {
            self.editMenu.alpha = 0
            }) { completed in
                if completed == true {
                    self.editMenu.removeFromSuperview()
                }
        }
    }
    
    @IBAction func onFilter(sender: UIButton) {
        if (sender.selected) {
            hideSecondaryMenu()
            sender.selected = false
        } else {
            showSecondaryMenu()
            sender.selected = true
        }
        
    }
    
    @IBAction func sliderValue(sender: UISlider) {
        self.sValue = Int(sender.value)
    }
    
    
    @IBAction func onBinary(sender: UIButton) {
        if binaryFilter.selected {
            if compareButton.enabled { compareButton.enabled = false }
            self.image = self.inputImage
            imageView.image = self.image
            binaryFilter.selected = false
            if brightFilter.selected { brightFilter.selected = false }
            if gaussFilter.selected { gaussFilter.selected = false }
            if blueFilter.selected { blueFilter.selected = false }
        } else {
            self.thresholdValue = UInt8((Double(self.sValue!) / Double(100.0)) * 255)
            if !compareButton.enabled { compareButton.enabled = true }
            self.filteredImage = Binary(RGBAImage(image: image!)!, threshold: self.thresholdValue!, negative: false).toUIImage()!
            self.image = self.filteredImage
            showFilteredImage()
            //imageView.image = self.image
            binaryFilter.selected = true
        }
    }
    
    @IBAction func onBright(sender: UIButton) {
        if brightFilter.selected {
            if compareButton.enabled { compareButton.enabled = false }
            self.image = self.inputImage
            imageView.image = self.image
            brightFilter.selected = false
            if binaryFilter.selected { binaryFilter.selected = false }
            if gaussFilter.selected { gaussFilter.selected = false }
            if blueFilter.selected { blueFilter.selected = false }
        } else {
            self.scalerValue = Double((Double(self.sValue!) / Double(100.0)) * 3)
            if !compareButton.enabled { compareButton.enabled = true }
            self.filteredImage = Brightness(RGBAImage(image: image!)!, scaler: self.scalerValue!).toUIImage()!
            self.image = self.filteredImage
            showFilteredImage()
            //imageView.image = self.image
            brightFilter.selected = true
        }
    }
    
    @IBAction func onGauss(sender: UIButton) {
        if gaussFilter.selected {
            if compareButton.enabled { compareButton.enabled = false }
            image = inputImage
            imageView.image = image
            gaussFilter.selected = false
            if binaryFilter.selected { binaryFilter.selected = false }
            if brightFilter.selected { brightFilter.selected = false }
            if blueFilter.selected { blueFilter.selected = false }
        } else {
            if !compareButton.enabled { compareButton.enabled = true }
            self.filteredImage = Gaussian(RGBAImage(image: image!)!, size: 3).toUIImage()!
            self.image = self.filteredImage
            showFilteredImage()
            //imageView.image = self.image
            gaussFilter.selected = true
        }
    }
    
    @IBAction func onBlue(sender: UIButton) {
        if blueFilter.selected {
            if compareButton.enabled { compareButton.enabled = false }
            self.image = self.inputImage
            imageView.image = self.image
            blueFilter.selected = false
            if binaryFilter.selected { binaryFilter.selected = false }
            if brightFilter.selected { brightFilter.selected = false }
            if gaussFilter.selected { gaussFilter.selected = false }
        } else {
            self.blueValue = Double((Double(self.sValue!) / Double(100.0)) * 3)
            if !compareButton.enabled { compareButton.enabled = true }
            self.filteredImage = Blue(RGBAImage(image: image!)!, scaler: self.blueValue!).toUIImage()!
            self.image = self.filteredImage
            showFilteredImage()
            //imageView.image = self.image
            blueFilter.selected = true
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        compareButton.enabled = false
        image = inputImage
        secondaryMenu.backgroundColor = UIColor.whiteColor().colorWithAlphaComponent(0.5)
        secondaryMenu.translatesAutoresizingMaskIntoConstraints = false
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func onCompare(sender: UIButton) {
        if compareButton.selected {
            self.image = self.filteredImage
            imageView.image = self.image
            compareButton.selected = false
        } else {
            self.image = self.inputImage
            imageView.image = self.image
            compareButton.selected = true
        }
    }
    
    @IBAction func onShare(sender: UIButton) {
        let activityController = UIActivityViewController(activityItems: [imageView.image!],
                                                          applicationActivities: nil)
        presentViewController(activityController, animated: true, completion: nil)
    }
    
    
    @IBAction func onNewPhoto(sender: UIButton) {
        let actionSheet = UIAlertController(title: "New Photo", message: nil, preferredStyle: .ActionSheet)
        actionSheet.addAction(UIAlertAction(title: "Camera",
                                            style: .Default,
                                            handler: { action in self.showCamera()} ))
        actionSheet.addAction(UIAlertAction(title: "Album",
                                            style: .Default,
                                            handler: { action in self.showAlbum()} ))
        actionSheet.addAction(UIAlertAction(title: "Cancel", style: .Cancel, handler: nil))
        
        self.presentViewController(actionSheet, animated: true, completion: nil)
    }
    
    func showCamera() {
        let cameraPicker = UIImagePickerController()
        cameraPicker.delegate = self
        cameraPicker.sourceType = .Camera
        
        presentViewController(cameraPicker, animated: true, completion: nil)
    }
    
    func showAlbum() {
        let cameraPicker = UIImagePickerController()
        cameraPicker.delegate = self
        cameraPicker.sourceType = .PhotoLibrary
        
        presentViewController(cameraPicker, animated: true, completion: nil)
    }
    
    func imagePickerController(picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : AnyObject]) {
        dismissViewControllerAnimated(true, completion: nil)
        if let image = info[UIImagePickerControllerOriginalImage] as? UIImage {
            imageView.image = image
        }
    }
    
    func imagePickerControllerDidCancel(picker: UIImagePickerController) {
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    func showFilteredImage() {
        //let toImage = UIImage(self.filteredImage)
        UIView.transitionWithView(self.imageView,
            duration: 0.5,
            options: UIViewAnimationOptions.TransitionCrossDissolve,
            animations: { self.imageView.image = self.image },
            completion: nil)
    }
    
    func showSecondaryMenu() {
        view.addSubview(secondaryMenu)
        
        let bottomConstraint = secondaryMenu.bottomAnchor.constraintEqualToAnchor(bottomMenu.topAnchor)
        let leftConstraint = secondaryMenu.leftAnchor.constraintEqualToAnchor(view.leftAnchor)
        let rightConstraint = secondaryMenu.rightAnchor.constraintEqualToAnchor(view.rightAnchor)
        let heightConstraint = secondaryMenu.heightAnchor.constraintEqualToConstant(44)
        
        NSLayoutConstraint.activateConstraints([bottomConstraint, leftConstraint, rightConstraint, heightConstraint])
        
        view.layoutIfNeeded()
        
        self.secondaryMenu.alpha = 0
        UIView.animateWithDuration(0.4) {
            self.secondaryMenu.alpha = 1.0
        }
    }
    
    func hideSecondaryMenu() {
        UIView.animateWithDuration(0.4, animations: {
            self.secondaryMenu.alpha = 0
            }) { completed in
                if completed == true {
                    self.secondaryMenu.removeFromSuperview()
                }
        }
    }
    
    // Create binary image around the value of threshold
    func Binary(image: RGBAImage, threshold: UInt8 = 125, negative: Bool = false) -> RGBAImage {
        let width = image.width
        let height = image.height
        var vals = [UInt8]()
        if negative { vals = [0, 255] }
        else { vals = [255, 0] }
        
        for x in 0..<width {
            for y in 0..<height {
                let index = y * width + x
                
                var pixel = image.pixels[index]
                
                if pixel.red > threshold { pixel.red = vals[0] }
                else { pixel.red = vals[1] }
                if pixel.green > threshold { pixel.green = vals[0] }
                else { pixel.green = vals[1] }
                if pixel.blue > threshold { pixel.blue = vals[0] }
                else { pixel.blue = vals[1] }
                
                image.pixels[index] = pixel
            }
        }
        return image
    }
    
    // Increase brightness of each image by scaler times
    func Brightness(image: RGBAImage, scaler: Double = 1) -> RGBAImage {
        let width = image.width
        let height = image.height
        for x in 0..<width {
            for y in 0..<height {
                let index = y * width + x
                
                var pixel = image.pixels[index]
                
                if (Double(pixel.red) * scaler) > 255 { pixel.red = 255 }
                else { pixel.red = UInt8(Double(pixel.red) * scaler) }
                if (Double(pixel.green) * scaler) > 255 { pixel.green = 255 }
                else { pixel.green = UInt8(Double(pixel.green) * scaler) }
                if (Double(pixel.blue) * scaler) > 255 { pixel.blue = 255 }
                else { pixel.blue = UInt8(Double(pixel.blue) * scaler) }
                
                image.pixels[index] = pixel
            }
        }
        return image
    }
    
    // Increase blueness of each image by scaler times
    func Blue(image: RGBAImage, scaler: Double = 1) -> RGBAImage {
        let width = image.width
        let height = image.height
        for x in 0..<width {
            for y in 0..<height {
                let index = y * width + x
                
                var pixel = image.pixels[index]
                
                if (Double(pixel.blue) * scaler) > 255 { pixel.blue = 255 }
                else { pixel.blue = UInt8(Double(pixel.blue) * scaler) }
                
                image.pixels[index] = pixel
            }
        }
        return image
    }
    
    // Generate Gaussian mask of size 2 * center - 1
    func GaussianMask(center: Int = 2, sigma: Float = 2) -> [Double] {
        let dim: Int = 2 * center - 1
        let size = dim * dim
        var mask = [Double](count: size, repeatedValue: 0.0)
        var power: Double
        for i in 1..<(dim + 1) {
            for j in 1..<(dim + 1) {
                let index = (j - 1) * dim + i - 1
                let e: Double = 2.71828
                power = -(pow(Double(i - center), 2.0) + pow(Double(j - center), 2)) / Double(2 * sigma)
                print(power)
                mask[index] = pow(e, power)
            }
        }
        // Normalize this bad boy
        var sum = mask[0]
        for i in 1..<size { sum = sum + mask[i] }
        for i in 0..<size { mask[i] = mask[i] / sum }
        return mask
    }
    
    // Convolve image with mask kernel
    func Convolve(image: RGBAImage, matWidth: Int, mask: [Double]) -> RGBAImage {
        let tempImage = image
        let maskDim = sqrt(Double(mask.count))
        let pixelCount = tempImage.height * tempImage.width
        let maskOffset = (maskDim - 1) / 2
        let window = maskOffset * Double(matWidth + 1)
        for i in Int(window)..<Int((Double(pixelCount) - window)) {
            var pixel = tempImage.pixels[i]
            var valueRed: UInt8 = 0
            var valueGrn: UInt8 = 0
            var valueBlu: UInt8 = 0
            let row: Int = i / matWidth
            let lower = ((row * (pixelCount % matWidth)) - Int(maskOffset))
            let upper = ((row * (pixelCount % matWidth)) + Int(maskOffset))
            if (lower < i && i < upper) {
                continue
            }
            var j = 0
            for p in Int(-1 * maskOffset)..<Int(maskOffset + 1) {
                for k in Int(-1 * maskOffset)..<Int(maskOffset + 1) {
                    let gIndex = i - (k * Int(matWidth)) + p
                    valueRed += UInt8(Double(image.pixels[gIndex].red) * mask[j])
                    valueGrn += UInt8(Double(image.pixels[gIndex].green) * mask[j])
                    valueBlu += UInt8(Double(image.pixels[gIndex].blue) * mask[j])
                }
                j += 1
            }
            pixel.red = valueRed
            pixel.green = valueGrn
            pixel.blue = valueBlu
            tempImage.pixels[i] = pixel
        }
        
        return tempImage
    }
    
    // Smooth out image and reduce Gaussian noise
    func Gaussian(image: RGBAImage, size: Int = 2) -> RGBAImage{
        let gMask: [Double] = GaussianMask(size, sigma: 10)
        return Convolve(image, matWidth: image.width, mask: gMask)
    }


}

